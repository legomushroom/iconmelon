2013 Webalys vincent.lemoign@gmail.com http://www.webalys.com/ 
MIT http://opensource.org/licenses/MIT 

